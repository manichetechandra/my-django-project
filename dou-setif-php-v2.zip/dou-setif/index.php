<?php
/**
 * نقطة الدخول الوحيدة للموقع (Front Controller).
 * كل الطلبات تمر من هنا عبر .htaccess ثم تُوجَّه حسب app/routes.php
 */

// خادم PHP المدمج (php -S): تقديم الملفات الثابتة مباشرة كما يفعل Apache: assets/ و uploads/،
// وملفات المتصفح (js, css, خطوط, صور) في أي مجلد آخر — مثل مجلد TinyMCE الخاص بك — عدا app/ database/ storage/
if (PHP_SAPI === 'cli-server') {
    $file = realpath(__DIR__ . rawurldecode((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH))) ?: '';
    $rel = str_replace('\\', '/', substr($file, strlen(__DIR__)));
    if ($file !== '' && is_file($file) && strpos($file, __DIR__ . DIRECTORY_SEPARATOR) === 0 && !preg_match('/\.(php\d?|phtml|phar)$/i', $file)
        && (preg_match('#^/(assets|uploads)/#', $rel) || (!preg_match('#^/(app|database|storage)/|/\.#', $rel)
            && preg_match('/\.(js|css|map|woff2?|ttf|eot|otf|svg|png|gif|jpe?g|webp|ico)$/i', $rel)))) {
        return false;
    }
}

require __DIR__ . '/app/bootstrap.php';

$router = new Router();
$GLOBALS['__router'] = $router;
require APP_PATH . '/routes.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path = request_path(); // يحدد لغة الطلب أيضاً: /fr/news/ => lang() = 'fr' و $path = '/news/'

// لوحة الإدارة عربية دائماً: /fr/admin/... => /admin/...
// والعربية بلا بادئة:        /ar/news/    => /news/
$qs = empty($_SERVER['QUERY_STRING']) ? '' : '?' . $_SERVER['QUERY_STRING'];
// redirect_path() تمنع "/ar//evil.com" => "//evil.com" (إعادة توجيه لموقع آخر)
if (lang() !== default_lang() && preg_match('#^/admin(/|$)#', $path)) {
    redirect(base_url() . route_prefix() . redirect_path($path) . $qs, 301);
}
if (preg_match('#^/' . default_lang() . '(/.*)?$#s', $path, $m)) {
    redirect(base_url() . route_prefix() . redirect_path($m[1] ?? '/') . $qs, 301);
}

// بيانات أكبر من post_max_size: يحذف PHP كل الحقول والملفات (ويفشل رمز CSRF) — نشرح السبب بدل صفحة خطأ غامضة
if ($method === 'POST' && !$_POST && !$_FILES && ($sent = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0)) > 0
    && ($max = ini_bytes((string) ini_get('post_max_size'))) > 0 && $sent > $max) {
    flash('error', __('حجم البيانات المرسلة ({sent} ميغابايت) أكبر من الحد المسموح به في الخادم ({max} ميغابايت). قلّل حجم الملفات ثم أعد المحاولة.',
        ['sent' => round($sent / 1048576, 1), 'max' => round($max / 1048576, 1)]));
    redirect(base_url() . route_prefix() . redirect_path(lang_prefix() . $path) . $qs);
}

// حماية CSRF لكل طلبات POST (مثل CsrfViewMiddleware)
if ($method === 'POST' && !verify_csrf()) {
    if (is_ajax() || str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json')) {
        json_response(['success' => false, 'error' => __('انتهت صلاحية الجلسة. أعد تحميل الصفحة.')], 403);
    }
    render('errors/403_csrf', [], 403);
    exit;
}

// إحصائيات الزوار (مثل VisitorTrackingMiddleware)
if (config('app.track_visits', true) && $method === 'GET') {
    track_visit($path);
}

$router->dispatch($method, $path);
